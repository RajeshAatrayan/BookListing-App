package com.example.rajeshaatrayan.booklisitngapp;

/**
 * Created by RajeshAatrayan on 17-06-2018.
 */
//holding book title and author name obtained from json parsing
public class Book {
    private String mTitle;
    private String mAuthor;

    Book(String mTitle, String mAuthor) {
        this.mAuthor = mAuthor;
        this.mTitle = mTitle;
    }

    public String getmTitle() {
        return mTitle;
    }

    public String getmAuthor() {
        return mAuthor;
    }
}
